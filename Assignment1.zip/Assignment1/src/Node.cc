

#include "Node.h"
#include "Packet_m.h"
#include "iostream"
#include <algorithm>    // std::unique, std::distance
#include "vector"
Define_Module(Node);
int a=15;
int count=0;
std::vector< int > arr;
int trip =1;
void Node::initialize()
{
    if (strcmp("A", getName()) == 0)
    {
        Packet *pck = new Packet();
        pck->setTTL(a);
        pck->setId(getId());
        pck->setMessages("Search");
        pck->setFrom(getName());
       // cMessage *msg = new cMessage("Searching");
        scheduleAt(simTime(), pck);
    }
}

void Node::handleMessage(cMessage *msg)
{
    Packet *pck =check_and_cast<Packet *>(msg);

    if ((strcmp("A", getName()) == 0 ) && (trip==2) &&(strcmp("Found", pck->getMessages()) == 0 )) {

        EV << "Message is from  " << pck->getFrom()<< "  saying: "<< pck->getMessages()<<endl;
        endSimulation (      ) ;
}
    if (strcmp("J", getName()) == 0 )
    {
        EV << "Message is from  " << pck->getFrom()<< "  saying: "<< pck->getMessages()<<endl;
        pck->setFrom(getName());
        pck->setMessages("Found");
        int n = gateSize("out");
        trip=2;
               for(int i = 0; i < n; i++)
               {
                   Packet *newmsg = pck->dup();
                   send(newmsg, "out", i);
               }

    }
    if(pck->isSelfMessage())
    {
        int n = gateSize("out");
        for(int i = 0; i < n; i++)
        {
            Packet *newmsg = pck->dup();
            send(newmsg, "out", i);
        }

    }


    if(pck->getTTL()>0)
    {

    int n = gateSize("out");
    arr.push_back(pck->getId());
           for(int i = 0; i < n; i++)
           {
               EV << "TTL is" << getId()<<endl;
               EV << "Message is from  " << pck->getFrom()<< "  saying: "<< pck->getMessages()<<endl;
               pck->setId(getId());
               pck->setTTL(pck->getTTL()-1);

               Packet *newmsg = pck->dup();
               send(newmsg, "out", i);
               if(pck->getTTL() <=0)  break;

               }



           }


    }



